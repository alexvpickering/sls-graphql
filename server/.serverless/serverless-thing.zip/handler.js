(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 4);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("graphql");

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

/*** IMPORTS FROM imports-loader ***/
var graphql = __webpack_require__(0);

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _serverlessDynamodbClient = __webpack_require__(11);

var _serverlessDynamodbClient2 = _interopRequireDefault(_serverlessDynamodbClient);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const AWSXRay = __webpack_require__(12);
const AWS = AWSXRay.captureAWS(__webpack_require__(2));

let docClient;

if (process.env.NODE_ENV === "production") {
  docClient = new AWS.DynamoDB.DocumentClient();
} else {
  docClient = _serverlessDynamodbClient2.default.doc;
}

exports.default = docClient;


/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("uuid");

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

/*** IMPORTS FROM imports-loader ***/
var graphql = __webpack_require__(0);

"use strict";

__webpack_require__(5);

var _apolloServerLambda = __webpack_require__(6);

var _graphqlPlaygroundMiddlewareLambda = __webpack_require__(7);

var _graphqlPlaygroundMiddlewareLambda2 = _interopRequireDefault(_graphqlPlaygroundMiddlewareLambda);

var _graphqlTools = __webpack_require__(8);

var _resolvers = __webpack_require__(9);

var _fs = __webpack_require__(18);

var _fs2 = _interopRequireDefault(_fs);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const schema = _fs2.default.readFileSync("schema.graphql", "utf8");

const myGraphQLSchema = (0, _graphqlTools.makeExecutableSchema)({
  typeDefs: schema,
  resolvers: _resolvers.resolvers,
  logger: console
});

exports.graphqlHandler = function graphqlHandler(event, context, callback) {
  // adds CORS then returns output
  function callbackFilter(error, output) {
    // eslint-disable-next-line no-param-reassign
    output.headers["Access-Control-Allow-Origin"] = "*";
    callback(error, output);
  }

  const handler = (0, _apolloServerLambda.graphqlLambda)({ schema: myGraphQLSchema, tracing: false });
  return handler(event, context, callbackFilter);
};

// for local endpointURL is /graphql and for prod it is /stage/graphql
exports.playgroundHandler = (0, _graphqlPlaygroundMiddlewareLambda2.default)({
  endpoint: process.env.REACT_APP_GRAPHQL_ENDPOINT ? process.env.REACT_APP_GRAPHQL_ENDPOINT : "/production/graphql"
});

exports.graphiqlHandler = (0, _apolloServerLambda.graphiqlLambda)({
  endpointURL: process.env.REACT_APP_GRAPHQL_ENDPOINT ? process.env.REACT_APP_GRAPHQL_ENDPOINT : "/production/graphql"
});


/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("babel-polyfill");

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = require("apollo-server-lambda");

/***/ }),
/* 7 */
/***/ (function(module, exports) {

module.exports = require("graphql-playground-middleware-lambda");

/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = require("graphql-tools");

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

/*** IMPORTS FROM imports-loader ***/
var graphql = __webpack_require__(0);

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.resolvers = undefined;

var _getThing = __webpack_require__(10);

var _getThing2 = _interopRequireDefault(_getThing);

var _getNestedThing = __webpack_require__(13);

var _getNestedThing2 = _interopRequireDefault(_getNestedThing);

var _createThing = __webpack_require__(14);

var _createThing2 = _interopRequireDefault(_createThing);

var _updateThing = __webpack_require__(15);

var _updateThing2 = _interopRequireDefault(_updateThing);

var _createNestedThing = __webpack_require__(16);

var _createNestedThing2 = _interopRequireDefault(_createNestedThing);

var _s3thing = __webpack_require__(17);

var _s3thing2 = _interopRequireDefault(_s3thing);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// eslint-disable-next-line import/prefer-default-export
const resolvers = exports.resolvers = {
  Query: {
    getThing: (root, args) => (0, _getThing2.default)(args),
    getNestedThing: (root, args) => (0, _getNestedThing2.default)(args)
  },
  Mutation: {
    createThing: (root, args) => (0, _createThing2.default)(args),
    createNestedThing: (root, args) => (0, _createNestedThing2.default)(args),
    updateThing: (root, args) => (0, _updateThing2.default)(args)
  },
  Thing: {
    s3thing: (root, args) => (0, _s3thing2.default)(args)
  }
};


/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

/*** IMPORTS FROM imports-loader ***/
var graphql = __webpack_require__(0);

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _docClient = __webpack_require__(1);

var _docClient2 = _interopRequireDefault(_docClient);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const getThing = args => {
  return _docClient2.default.get({
    TableName: "Things",
    Key: {
      id: args.id
    }
  }).promise().then(res => res.Item).catch(err => console.log(err));
};

exports.default = getThing;


/***/ }),
/* 11 */
/***/ (function(module, exports) {

module.exports = require("serverless-dynamodb-client");

/***/ }),
/* 12 */
/***/ (function(module, exports) {

module.exports = require("aws-xray-sdk");

/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

/*** IMPORTS FROM imports-loader ***/
var graphql = __webpack_require__(0);

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _docClient = __webpack_require__(1);

var _docClient2 = _interopRequireDefault(_docClient);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const getNestedThing = args => {
  return _docClient2.default.get({
    TableName: "NestedThings",
    Key: {
      id: args.id
    }
  }).promise().then(res => res.Item).catch(err => console.log(err));
};

exports.default = getNestedThing;


/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

/*** IMPORTS FROM imports-loader ***/
var graphql = __webpack_require__(0);

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _uuid = __webpack_require__(3);

var _uuid2 = _interopRequireDefault(_uuid);

var _docClient = __webpack_require__(1);

var _docClient2 = _interopRequireDefault(_docClient);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const createThing = args => {
  console.log(args);
  const Item = {
    id: _uuid2.default.v4(),
    one: args.one,
    two: args.two
  };

  // put into dynamodb then return above Item
  return _docClient2.default.put({
    TableName: "Things",
    Item
  }).promise().then(res => Item).catch(err => console.log(err));
};

exports.default = createThing;


/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

/*** IMPORTS FROM imports-loader ***/
var graphql = __webpack_require__(0);

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _docClient = __webpack_require__(1);

var _docClient2 = _interopRequireDefault(_docClient);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const updateThing = args => {
  const expAtrVals = {};
  let upExp = "SET";

  // to check if adding comma
  const last = Object.keys(args).length - 1;

  Object.entries(args).forEach(([key, val], ind) => {
    if (key === "id") return;

    // add to UpdateExpression
    upExp = `${upExp} ${key} = :${key}${ind === last ? "" : ", "}`;

    // add to ExpressionAttributeValues
    expAtrVals[`:${key}`] = val;
  });

  return _docClient2.default.update({
    TableName: "Things",
    Key: { id: args.id },
    UpdateExpression: upExp,
    ConditionExpression: "attribute_exists(id)",
    ExpressionAttributeValues: expAtrVals,
    ReturnValues: "ALL_NEW"
  }).promise().then(res => res.Attributes).catch(err => console.log(err));
};

exports.default = updateThing;


/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

/*** IMPORTS FROM imports-loader ***/
var graphql = __webpack_require__(0);

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _uuid = __webpack_require__(3);

var _uuid2 = _interopRequireDefault(_uuid);

var _docClient = __webpack_require__(1);

var _docClient2 = _interopRequireDefault(_docClient);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const createNestedThing = args => {
  const Item = {
    id: _uuid2.default.v4(),
    things: args.things
  };
  console.log(JSON.stringify(Item, null, 2));

  // put into dynamodb then return above Item
  return _docClient2.default.put({
    TableName: "NestedThings",
    Item
  }).promise().then(res => Item).catch(err => console.log("error"));
};

exports.default = createNestedThing;


/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

/*** IMPORTS FROM imports-loader ***/
var graphql = __webpack_require__(0);

"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
const AWS = __webpack_require__(2);

const s3thing = args => {
  const s3 = new AWS.S3();
  console.log(args);

  s3.getObject({
    Bucket: "serverless-thing-files",
    Key: `s3thing${args.id}.json`
  }).promise();
  // .then(data => data.Body.toString("utf-8"))
  // .catch(console.log("Failed to retrieve an object: "));
};

exports.default = s3thing;


/***/ }),
/* 18 */
/***/ (function(module, exports) {

module.exports = require("fs");

/***/ })
/******/ ])));